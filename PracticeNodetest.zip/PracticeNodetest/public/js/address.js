mapboxgl.accessToken = 'pk.eyJ1Ijoic3dhc3RpazMwMDUiLCJhIjoiY2tiYW1rbGFvMHA5ZzJ4bzhkanZhdHN1aCJ9.z6gwp_4Wjn7OKBi6tIeP1A';
const long = 88.3639
const lat = 22.5726
var map = new mapboxgl.Map({
container: 'map',
style: 'mapbox://styles/mapbox/streets-v11',
center: [long, lat], // starting position,]
zoom: 12 // starting zoom
});
var geocoder = new MapboxGeocoder({ // Initialize the geocoder
    accessToken: mapboxgl.accessToken, // Set the access token
    mapboxgl: map, // Set the mapbox-gl instance
    marker: false, // Do not use the default marker style
    placeholder: 'Search for places', // Placeholder text for the search bar
    bbox: [86.572266,21.575719,89.033203,24.287027], // Boundary for Kolkata
    proximity: {
      longitude: 88.325161,
      latitude: 22.510769
    } 
  });

map.addControl(geocoder);
map.addControl(new mapboxgl.NavigationControl());
map.addControl(
  new mapboxgl.GeolocateControl({
  positionOptions: {
  enableHighAccuracy: true
  },
  trackUserLocation: true
  })
  );
  
  map.on('click', function(e) {
    var lngLat = e.lngLat;
    var marker = new mapboxgl.Marker({
        color: '#472387'
    })
    .setLngLat([lngLat.lng, lngLat.lat])
    .addTo(map);
    var lngLat = e.lngLat;
    fetch('/admin/getcoords?lat='+lngLat.lat+'&lng='+lngLat.lng)
    .then((result) => {
        return result.json();
    }).then((data) => {
        document.getElementById("description").value = data.address;
        document.getElementById("lat").value = lngLat.lat;
        document.getElementById("lng").value = lngLat.lng;
    }).catch((err) => {
        console.log(err);
        })
    })