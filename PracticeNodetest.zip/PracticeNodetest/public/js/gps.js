navigator.geolocation.getCurrentPosition((position) =>{
    fetch('/getuserloc?lat=' + position.coords.latitude +'&lng=' + position.coords.longitude)
        .then(result => {
          return result.json();
        })
        .then(data => {
          console.log(data);
        })
        .catch(err => {
          console.log(err);
        });
    
})