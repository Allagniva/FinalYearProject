mapboxgl.accessToken = 'pk.eyJ1Ijoic3dhc3RpazMwMDUiLCJhIjoiY2tiYW1rbGFvMHA5ZzJ4bzhkanZhdHN1aCJ9.z6gwp_4Wjn7OKBi6tIeP1A';
const long = 88.3639
const lat = 22.5726
var map = new mapboxgl.Map({
container: 'map',
style: 'mapbox://styles/mapbox/streets-v11',
center: [long, lat], // starting position,]
zoom: 12 // starting zoom
});

var geocoder = new MapboxGeocoder({ // Initialize the geocoder
  accessToken: mapboxgl.accessToken, // Set the access token
  mapboxgl: map, // Set the mapbox-gl instance
  marker: false, // Do not use the default marker style
  placeholder: 'Search for places', // Placeholder text for the search bar
  bbox: [86.572266,21.575719,89.033203,24.287027], // Boundary for Kolkata
  proximity: {
    longitude: 88.325161,
    latitude: 22.510769
  } 
});
map.addControl(geocoder);
map.addControl(new mapboxgl.NavigationControl());
map.addControl(
  new mapboxgl.GeolocateControl({
  positionOptions: {
  enableHighAccuracy: true
  },
  trackUserLocation: true
  })
  );

getLatLng = () => {
    fetch('/points')
      .then(result => {
        return result.json();
      })
      .then((data) => {
          const points = data.map(p => {
            return {
              coordinates: [p.location.coordinates[0], p.location.coordinates[1]],
              title: p.title,
              id: p._id,
              imageUrl: p.imageUrl,
              address: p.description
            };
          });
          loadMap(points);
      })
      .catch(err => {
        console.log(err);
      });
  };

 

  function loadMap(coords) {
    function addMarker(points) {

      var el = document.createElement('div');
      el.className = 'marker';

      var marker = new mapboxgl.Marker(el)
      .setLngLat(points.coordinates)
      .setPopup(new mapboxgl.Popup()
      .setHTML(
        `<head>
        <link rel="stylesheet" href="/css/main.css">
        <link rel="stylesheet" href="/css/product.css">
        <link rel="stylesheet" href="/css/admin-product.css">
        </head>
        
        <body>
        <div class="grid-admin">
        <article class="carda product-item">
        <header class="card__header-admin">
            <h1 class="product__title">${points.title}</h1>
        </header>
        <div class="card__image-admin">
            <img src="/${points.imageUrl}"
                alt="">
        </div>
        <div class="card__content-admin">
    
            <p class="product__description">${points.address}</p>
          </div>
        <div class="card__actions-admin">
            <a class="btn" href="/product/${points.id}">Details</a>
        </div>
        </article>
        </div>
        </body>
        `
        ))
      .addTo(map);
    }
    map.on('load', function() {
      for(var i = 0;i < coords.length;i++){
        addMarker(coords[i]);
      }
    });
  }
  getLatLng();
