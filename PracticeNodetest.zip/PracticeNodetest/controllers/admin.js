const Product = require('../models/product');
const User = require('../models/user');
const fileHelper = require('../util/file');
const Geocoding = require('@mapquest/geocoding');
const path = require('path');
const client = new Geocoding({key: 'ZAQRsJtxXkQkVjz8ViCHGrCG0IUWLul4'});
const {getDistance, convertDistance} = require('geolib');
const ITEMS_PER_PAGE = 3;

exports.getProduct = (req, res, next) => {
  const page = +req.query.page || 1;
  Product.find({userId: req.user._id}).countDocuments().then((nProducts) => {
    totalItems = nProducts;
    return Product.find({userId: req.user._id}).sort({"created_at": -1})
    .skip((page - 1)*ITEMS_PER_PAGE)
    .limit(ITEMS_PER_PAGE)
  }).then((products) => {
    res.render('admin/products', {
      prods: products,
      pageTitle: 'Admin Products',
      path: '/admin/products',
      totalItems: totalItems,
      hasNextPage: (ITEMS_PER_PAGE*page) < totalItems,
      nextPage: page + 1,
      hasPrevPage: page > 1,
      prevPage: page - 1,
      lastPage: Math.ceil(totalItems / ITEMS_PER_PAGE),
      currentPage: page  
    });
  }).catch(err => {
    console.log(err);
  });
};

exports.getFavourites = (req, res, next) => {
  const filter =+req.query.filter || 0;
  req.user.populate('marked.productId').execPopulate()
  .then((products) => {
    const new_product = products.marked.map(p =>{
      return {
        imageUrl: p.productId.imageUrl,
        title: p.productId.title,
        price: p.productId.price,
        id: p.productId._id,
        distance: convertDistance(getDistance({latitude: p.productId.location.coordinates[1], longitude: p.productId.location.coordinates[0]}, req.session.curr_coords),'km').toFixed(1)
      }
    })  
    const sorted_product = new_product.sort((a,b) => {
      if(filter == 1){
        return a.price-b.price;
      }else if(filter == -1){
        return b.price-a.price
      }else{
      return a.distance-b.distance;
      }
    })
    res.render('shop/product-list', {
      prods: sorted_product,
      pageTitle: 'Favourites',
      path: '/admin/favourites',
      filter: filter
    });
  }).catch(err =>{
    console.log(err);
  });
};

exports.getAddProduct = (req, res, next) => {
    res.render('admin/edit-product', {
      pageTitle: 'Add Product',
      path: '/admin/add-product',
      editting: false,
      
    });
  };

  exports.postAddProduct= (req, res, next) => {
    const title = req.body.title;
    const image = req.file.location;
    const price = req.body.price;
    const description = req.body.description;
    const lat = req.body.lat;
    const lng = req.body.lng;
    const userId = req.user;
    
    const location = {
      type: 'Point',
      coordinates: [lng,lat]
    }

    const product = new Product({
      title: title,
      price: price,
      description: description,
      location: location,
      imageUrl: image,
      userId: userId
    });
    product.save().then((result) => {
      //console.log(result);
      console.log('Product Created');
      res.redirect('/');
    }).catch(err => {
      console.log(err);
    });
  };

exports.getEditProduct = (req, res, next) => {
  const editMode = req.query.edit;
  const prodId = req.params.productId;
  Product.findById(prodId).then((proDuct) =>{
    if(!proDuct){
      return res.redirect('/');
    }
    res.render('admin/edit-product',{
      pageTitle: 'Edit Product',
      path: '/admin/edit-product',
      editting: editMode,
      product:proDuct
    })
  }).catch(err => {
    console.log(err);
  });
};

exports.postEditProduct = (req, res, next) => {
  const prodId = req.body.productId;
  const updatedTitle = req.body.title;
  if(req.file){
    var updatedImage = req.file.location;  
  }
  const updatedPrice = req.body.price;
  const updatedDesc = req.body.description;
  const updatedLat = req.body.lat;
  const updatedLng = req.body.lng;
  const updatedLocation = {
    type: 'Point',
    coordinates: [updatedLng,updatedLat]
  }
  Product.findById(prodId)
  .then((product) => {
    product.title = updatedTitle;
    product.price = updatedPrice;
    product.description = updatedDesc;
    product.location = updatedLocation;
    if(req.file){
      fileHelper.deleteFile(product.imageUrl);
      product.imageUrl = updatedImage;
    }
    return product.save();
  }).then((result) => {
   // console.log(result);
    console.log('Product Updated');
    res.redirect('/admin/products');
  }).catch(err => {
    console.log(err);
  })
};

exports.postDeleteProduct = (req, res, next) => {
  const prodId = req.params.productId;
  Product.findById(prodId)
  .then((product) => {
    fileHelper.deleteFile(product.imageUrl);
    return Product.findByIdAndRemove(prodId);
  })
  .then(() => {
    console.log('Product Deleted');
    res.status(200).json({ message: 'Success!' });
  }).catch(err => {
    res.status(500).json({ message: 'Deleting product failed.' });
  })
};

exports.getCoords = (req, res, next) => {
  const lat = req.query.lat;
  const lng = req.query.lng;
  client.reverse(lat, lng)
  .then(result => {
    res.status(200).json({
      'address': result.addressString,
    })
   }).catch((err) => {
    console.log(err);
   })

}

exports.getEditProfile = (req, res, next) => {
  res.render('admin/edit-profile',{
    errorMessage: '',
    email: req.user.email,
    path: '/admin/edit-profile',
    pageTitle: 'Edit Profile'
  })
}

exports.postEditProfile = (req, res, next) => {
  const name = req.body.fname;
  if(req.file){
    var imageUrl = req.file.location;
  }
  const email = req.body.email;
  User.findById(req.user._id)
  .then((user) => {
    user.name = name;
    if(req.file){
      fileHelper.deleteFile(user.imageUrl);
      user.imageUrl = imageUrl; 
      }
    user.email = email;
    return user.save();
  }).then((user) => {
    res.redirect('/');
  }).catch(err => {
    console.log(err);
  })
}

exports.getDeleteAccount = (req, res, next) => {
  Product.find({userId: req.user._id})
  .then((product) => {
    for( p of product){
      fileHelper.deleteFile(p.imageUrl);
    }
    return Product.deleteMany({userId: req.user._id})
  }).then(() => {
    return User.findById(req.user._id)
  })
  .then((user) => {
    fileHelper.deleteFile(user.imageUrl);
    return User.findByIdAndRemove(user._id);
  })
  .then(() => {
    req.session.destroy((err) => {
      res.redirect('/');
      if(err){
        console.log(err);
      }else{
        console.log('Account Deleted');   
      }
    });
  }).catch(err => {
    console.log(err);
    
  })
}