const Product = require('../models/product');
const User = require('../models/user');
const fs = require('fs');
const path = require('path');
const {getDistance, convertDistance} = require('geolib');

// product-list
exports.getProducts= (req, res, next) => {
  const filter =+req.query.filter || 0;
  Product.find()
  .then((products) => {
    const new_product = products.map(p =>{
      return {
        imageUrl: p.imageUrl,
        title: p.title,
        price: p.price,
        id: p.id,
        distance: convertDistance(getDistance({latitude: p.location.coordinates[1], longitude: p.location.coordinates[0]}, req.session.curr_coords),'km').toFixed(1)
      }
    })
    
    const sorted_product = new_product.sort((a,b) => {
      if(filter == 1){
        return a.price-b.price;
      }else if(filter == -1){
        return b.price-a.price
      }else{
      return a.distance-b.distance;
      }
    })
    res.render('shop/product-list', {
      prods: sorted_product,
      pageTitle: 'All Products',
      path: '/product',
      filter: filter
    });
  }).catch(err =>{
    console.log(err);
  });
};
//Get Products by Id
exports.findProduct = (req, res, next) => {
  const prodId = req.params.productId;
  Product.findById(prodId).then((product) => {
    return product.populate('userId').execPopulate()
  }).then((proDuct) => {
    res.render('shop/product-details',{
      product: proDuct,
      pageTitle: proDuct.title,
      path: '/product',
      distance: convertDistance(getDistance({latitude: proDuct.location.coordinates[1], longitude: proDuct.location.coordinates[0]}, req.session.curr_coords),'km').toFixed(1)
    })
  }).catch(err => {
    console.log(err); 
  });
};

// Index
exports.getIndex = (req, res, next) => {
    res.render('shop/index', {
      pageTitle: 'Welcome to Home',
      path: '/',
    });
};

exports.getPoints = (req, res, next) => {
  Product.find()
  .then((products) => {
    res.status(200).json(products);
  })
  .catch((err) => {
    console.log(err);
    
  })
};

