const Geocoding = require('@mapquest/geocoding')
const client = new Geocoding({key: 'ZAQRsJtxXkQkVjz8ViCHGrCG0IUWLul4'})

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const productSchema = new Schema({
  title: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  location: {
    type: {
      type: String,
      enum: ['Point']
    },
    coordinates: {
      type: [Number],
      index: '2dsphere'
    }
  }
  ,
  imageUrl: {
    type: String,
    required: true
  },
 created_at: {
  type: Date,
  default: Date.now()
 },
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
});

productSchema.pre('save',function(next) {
  client.forward(this.description)
  .then(result => {
    if(this.location.coordinates[0] == null){
    this.location = {
      type: 'Point',
      coordinates: [result.geometry.coordinates[0],result.geometry.coordinates[1]]
    }
  }
    next();
   }).catch((err) => {
    console.log(err);
   })
})

module.exports = mongoose.model('Product',productSchema)