const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const userSchema = new Schema({
  name: {
    type: String
  },
  imageUrl: {
    type: String,
    required: true
  },
  phone: {
    type: Number
  },
  email: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  marked: [{
    productId: {
      type: Schema.Types.ObjectId,
      ref: 'Product',
    }
  }],
  resetToken: String,
  resetTokenExpiration: Date,
});

userSchema.methods.addmarked = function(productId) {
  let updatedMarked = [...this.marked];
    var present = updatedMarked.some((p) => {
      return p.productId.toString() === productId.toString();
    })
    
    if(!present){
      updatedMarked.push({
        productId: productId
      })
    }else{
      updatedMarked = updatedMarked.filter((p) => {
        return p.productId.toString() !== productId.toString();
      })
    }
  this.marked = updatedMarked;
  return this.save();
}

module.exports = mongoose.model('User',userSchema);

