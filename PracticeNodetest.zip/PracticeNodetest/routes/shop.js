const isAuth = require('../middleware/isAuth')

const express = require('express');
 
const shopController = require('../controllers/shop');

const router = express.Router();

router.get('/', shopController.getIndex);

router.get('/product', shopController.getProducts);

router.get('/product/:productId', shopController.findProduct);

router.get('/points',shopController.getPoints);

module.exports = router;
