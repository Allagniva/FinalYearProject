const path = require('path');

const express = require('express');

const adminController = require('../controllers/admin');

const isAuth = require('../middleware/isAuth')

const router = express.Router();

// /admin/products => GET
router.get('/products', isAuth, adminController.getProduct);

// /admin/favourites => GET
router.get('/favourites',adminController.getFavourites)

// /admin/add-product => GET
router.get('/add-product', isAuth, adminController.getAddProduct);

// /admin/add-product => POST
router.post('/add-product', adminController.postAddProduct);

// /admin/edit-product => GET
router.get('/edit-product/:productId', adminController.getEditProduct);

// /admin/edit-product => POST

router.post('/edit-product',adminController.postEditProduct);

// /admin/delete-product => POST

router.delete('/product/:productId',adminController.postDeleteProduct);

router.get('/getcoords',adminController.getCoords);

router.get('/edit-profile',adminController.getEditProfile);

router.post('/edit-profile',adminController.postEditProfile);

router.get('/delete-account',adminController.getDeleteAccount);

module.exports = router;
